export interface AttributesI {
  sidebar: string;
}
