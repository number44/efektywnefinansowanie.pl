(function init() {
  alert("działam sdasda");
})();
