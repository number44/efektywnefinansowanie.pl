const PanelMedia = () => {
  return <div>PanelMedia</div>;
};

export default PanelMedia;
