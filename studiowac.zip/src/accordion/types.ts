export interface AttributesI {
  accordions: AccordionI[];
}

interface AccordionI {
  title: string;
  content: string;
}
