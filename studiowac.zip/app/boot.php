<?php
// Include Composer's autoloader
// Use GuzzleHTTP client

namespace App;


use App\Api\Api;


Api::register();




